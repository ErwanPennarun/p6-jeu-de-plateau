class Weapon {
    constructor(name, force, className) {
        this.name = name;
        this.force = force;
        this.className = className;

    }
}

